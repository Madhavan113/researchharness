Find sources for the user's brief. Inspect and probe the actual source,
retain original evidence, and submit a validated proposal with honest limitations.
