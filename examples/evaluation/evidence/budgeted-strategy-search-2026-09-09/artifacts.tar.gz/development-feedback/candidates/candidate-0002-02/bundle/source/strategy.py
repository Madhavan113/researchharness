import json
def apply(event):
    payload = event['payload']
    if event['kind'] == 'context':
        decision = {'keep_group_ids': payload['required_group_ids']}
    else:
        items = sorted(payload['items'], key=lambda item: json.dumps(item['value'], sort_keys=True), reverse=True)
        decision = {'order': [item['id'] for item in items]}
    return {'decision': decision, 'state': {'calls': event['state'].get('calls', 0) + 1, 'iteration': 2}}
