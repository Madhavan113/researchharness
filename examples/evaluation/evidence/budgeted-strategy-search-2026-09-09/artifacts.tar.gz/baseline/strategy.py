def apply(event):
    payload = event['payload']
    if event['kind'] == 'context':
        decision = {'keep_group_ids': [group['id'] for group in payload['groups']]}
    else:
        decision = {'order': [item['id'] for item in payload['items']]}
    return {'decision': decision, 'state': {'calls': event['state'].get('calls', 0) + 1}}
