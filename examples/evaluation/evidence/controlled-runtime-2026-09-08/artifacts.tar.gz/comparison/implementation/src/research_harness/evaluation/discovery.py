"""Score sampled source selection without accepting the agent's coverage claims.

Artifact files must be produced by the trusted runner. Content hashes provide
reproducibility, not authentication or isolation from generated strategy code.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from research_harness.config import PipelineSpec, SourceSpec
from research_harness.evaluation.usage import verify_runtime_usage
from research_harness.util import canonical_json, digest, http_url


def matches(value: Any, expected: Any) -> bool:
    """Objects are subset predicates; scalars and lists require exact equality."""
    if isinstance(expected, dict):
        return isinstance(value, dict) and all(
            key in value and matches(value[key], target) for key, target in expected.items()
        )
    return type(value) is type(expected) and value == expected


def validate_requirements(requirements: Any) -> list[dict]:
    if not isinstance(requirements, list) or not requirements:
        raise ValueError("Supply at least one independent requirement")
    seen: set[str] = set()
    for requirement in requirements:
        if not isinstance(requirement, dict):
            raise TypeError("Requirements must be objects")
        identity = requirement.get("id")
        if not isinstance(identity, str) or not identity.strip() or identity in seen:
            raise ValueError("Requirement ids must be nonempty and unique")
        seen.add(identity)
        weight = requirement.get("weight", 1)
        if type(weight) not in (int, float) or not math.isfinite(weight) or weight <= 0:
            raise ValueError("Requirement weights must be finite and positive")
        alternatives = requirement.get("any_of")
        if not isinstance(alternatives, list) or not alternatives:
            raise ValueError(f"{identity}: supply acceptable source predicates")
        for alternative in alternatives:
            if not isinstance(alternative, dict) or not isinstance(alternative.get("url"), str):
                raise ValueError(f"{identity}: each source predicate needs an exact URL")
            http_url(alternative["url"])
            if not isinstance(alternative.get("connector"), str) or not alternative["connector"]:
                raise ValueError(f"{identity}: each predicate needs a connector")
            unknown = set(alternative) - set(SourceSpec.model_fields)
            if unknown:
                raise ValueError(f"{identity}: unknown source fields {sorted(unknown)}")
    return requirements


def _objects(value: Any, label: str) -> list[dict]:
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise ValueError(f"{label} must be a list of objects")
    return value


def _result_urls(kind: str, result: dict) -> set[str]:
    def urls(items: Any) -> set[str]:
        return (
            {
                item["url"]
                for item in items
                if isinstance(item, dict) and isinstance(item.get("url"), str)
            }
            if isinstance(items, list)
            else set()
        )

    if kind == "search":
        return (
            urls(result.get("results"))
            if result.get("status") not in {"error", "failed"}
            else set()
        )
    observed = urls(result.get("captures"))
    # A failed request's configured URL alone does not prove the page was observed.
    captured = (kind == "inspection" and result.get("capture_id")) or (
        kind == "probe" and result.get("status") == "verified_sample"
    )
    if captured and isinstance(result.get("url"), str):
        observed.add(result["url"])
    return observed


def observed_urls(
    events: list[dict], receipts: list[dict], discovery_id: str | None, errors: list[str]
) -> set[str]:
    observed: set[str] = set()

    def receipt(kind: Any, result: Any, scope: Any) -> None:
        if kind not in {"search", "inspection", "probe"} or not isinstance(result, dict):
            return
        if discovery_id is not None and scope != discovery_id:
            errors.append("Evidence receipt belongs to a different or unspecified discovery")
            return
        observed.update(_result_urls(kind, result))

    for item in receipts:
        receipt(item.get("kind"), item.get("payload"), item.get("discovery_id"))
    for event in events:
        if event.get("event") == "service_receipt":
            receipt(event.get("kind"), event.get("result"), event.get("discovery_id"))
        if event.get("event") == "model_response":
            for item in _objects(event.get("output", []), "Model response output"):
                if item.get("type") == "web_search_call" and item.get("status") == "completed":
                    action = item.get("action") or {}
                    if isinstance(action, dict):
                        observed.update(_result_urls("search", {"results": action.get("sources")}))
        if event.get("event") == "tool_result":
            kind = {
                "inspect_url": "inspection",
                "inspect_source": "inspection",
                "probe_source": "probe",
            }.get(event.get("tool"))
            result = event.get("result")
            if kind and isinstance(result, dict):
                observed.update(_result_urls(kind, result))
    return observed


def token_usage(proposal: dict) -> int | None:
    usage = proposal.get("usage")
    if not isinstance(usage, dict):
        return None
    values = [usage.get("input_tokens"), usage.get("output_tokens")]
    if any(type(value) is not int or value < 0 for value in values):
        return None
    return sum(values)


def score(artifacts: Path, specification: dict, *, runtime_usage: Path | None = None) -> dict:
    """Read one completed run and grade source selection, not full ingestion.

    Bad/missing input files or malformed specification raise ValueError/OSError.
    Inconsistent research evidence yields status=invalid and zero quality.
    """
    if not isinstance(specification, dict):
        raise ValueError("The independent specification must be an object")
    requirements = validate_requirements(specification.get("requirements"))
    artifacts = Path(artifacts)
    hashes: dict[str, str] = {}

    def read(name: str, default: Any = None, *, optional: bool = False) -> Any:
        path = artifacts / name
        if optional and not path.exists():
            return default
        raw = path.read_bytes()
        hashes[name] = digest(raw)
        if name.endswith(".jsonl"):
            return [json.loads(line) for line in raw.splitlines() if line.strip()]
        return json.loads(raw)

    proposal = read("proposal.json")
    if not isinstance(proposal, dict) or not isinstance(proposal.get("proposal"), dict):
        raise ValueError("proposal.json must contain a saved proposal object")
    usage_path = (
        Path(runtime_usage)
        if runtime_usage is not None
        else artifacts / "omnigent/runtime-usage.discovery.json"
    )
    usage_evidence = None
    if runtime_usage is not None or usage_path.exists():
        usage_evidence = verify_runtime_usage(usage_path, proposal)
        hashes.update({key: value["sha256"] for key, value in usage_evidence["files"].items()})
    candidates = _objects(proposal["proposal"].get("candidates"), "Proposal candidates")
    if not candidates:
        raise ValueError("A saved proposal must contain candidates")
    traces = _objects(read("trace.jsonl"), "Trace events")
    probes = _objects(read("probes.json", [], optional=True), "Probes")
    receipts = _objects(read("receipts.json", [], optional=True), "Receipts")
    pipeline = read("pipeline.json", optional=True)
    errors: list[str] = []
    registration = proposal.get("registry") or {}
    discovery_id = registration.get("discovery_id") if isinstance(registration, dict) else None
    observed = observed_urls(traces, receipts, discovery_id, errors)
    by_probe: dict[str, dict] = {}
    for probe in probes:
        identity = probe.get("probe_id")
        if not isinstance(identity, str) or not identity or identity in by_probe:
            errors.append("Probe ids must be present and unique")
            continue
        if discovery_id and probe.get("discovery_id", discovery_id) != discovery_id:
            errors.append(f"{identity}: probe belongs to another discovery")
            continue
        by_probe[identity] = probe
        observed.update(_result_urls("probe", probe))

    ready: dict[str, dict] = {}
    valid_sources: list[dict] = []
    for index, candidate in enumerate(candidates):
        before = len(errors)
        label = candidate.get("name", f"candidate {index}")
        citations = candidate.get("evidence_urls")
        if (
            not isinstance(citations, list)
            or not citations
            or any(not isinstance(url, str) or url not in observed for url in citations)
        ):
            errors.append(f"{label}: missing or unobserved source citation")
        status = candidate.get("status")
        if status not in {"ready", "needs_connector", "needs_access", "unavailable"}:
            errors.append(f"{label}: unknown candidate status")
        if status != "ready":
            continue
        try:
            spec = SourceSpec.model_validate(candidate.get("source"))
        except ValidationError:
            errors.append(f"{label}: ready candidate has an invalid SourceSpec")
            continue
        source = spec.model_dump(mode="json")
        if spec.id in ready:
            errors.append(f"{spec.id}: duplicate source id")
        ready[spec.id] = source
        probe_id = candidate.get("probe_id")
        proof = by_probe.get(probe_id) if isinstance(probe_id, str) else None
        if not spec.enabled:
            errors.append(f"{spec.id}: ready source is disabled")
        if not proof or proof.get("status") != "verified_sample":
            errors.append(f"{spec.id}: missing successful probe")
        elif proof.get("source_fingerprint") != spec.fingerprint():
            errors.append(f"{spec.id}: source changed after its probe")
        elif type(proof.get("record_count")) is not int or proof["record_count"] <= 0:
            errors.append(f"{spec.id}: probe did not produce records")
        if len(errors) == before:
            valid_sources.append(source)

    compiled: dict[str, dict] = {}
    if pipeline is not None:
        try:
            compiled_spec = PipelineSpec.model_validate(pipeline)
            compiled = {
                source.id: source.model_dump(mode="json") for source in compiled_spec.sources
            }
        except ValidationError:
            errors.append("Compiled pipeline is not a valid PipelineSpec")
    if compiled != ready:
        errors.append("Compiled pipeline does not match the ready candidate configurations")

    coverage = []
    relevant: set[int] = set()
    total_weight = covered_weight = 0.0
    for requirement in requirements:
        weight = requirement.get("weight", 1)
        total_weight += weight
        matching = [
            index
            for index, source in enumerate(valid_sources)
            if any(matches(source, predicate) for predicate in requirement["any_of"])
        ]
        relevant.update(matching)
        if matching:
            covered_weight += weight
        coverage.append(
            {
                "id": requirement["id"],
                "covered": bool(matching),
                "source_ids": [valid_sources[index]["id"] for index in matching],
            }
        )
    recall = covered_weight / total_weight
    precision = len(relevant) / len(ready) if ready else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "evaluator_version": 1,
        "scope": "sampled_source_selection",
        "status": "invalid" if errors else "ok",
        "quality": 0.0 if errors else f1,
        "requirement_recall": recall,
        "source_precision": precision,
        "total_tokens": usage_evidence["total_tokens"] if usage_evidence else token_usage(proposal),
        "completed_token_lower_bound": usage_evidence["completed_token_lower_bound"]
        if usage_evidence
        else token_usage(proposal),
        "runtime_usage": usage_evidence,
        "reported_model": proposal.get("model"),
        "reported_search_providers": sorted(
            {
                receipt["payload"]["provider"]
                for receipt in receipts
                if receipt.get("kind") == "search"
                and isinstance(receipt.get("payload"), dict)
                and isinstance(receipt["payload"].get("provider"), str)
            }
        ),
        "coverage": coverage,
        "errors": errors,
        "artifacts": str(artifacts.resolve()),
        "specification_sha256": digest(canonical_json(specification)),
        "artifact_sha256": hashes,
    }


def frontier(results: list[dict]) -> list[dict]:
    """Maximize quality and minimize known model tokens for one specification."""
    specifications = {
        result["specification_sha256"] for result in results if "specification_sha256" in result
    }
    if len(specifications) > 1:
        raise ValueError("Only compare runs scored against the same specification")
    eligible = [
        result
        for result in results
        if result.get("status") == "ok"
        and type(result.get("total_tokens")) is int
        and result["total_tokens"] >= 0
        and type(result.get("quality")) in (int, float)
        and math.isfinite(result["quality"])
        and 0 <= result["quality"] <= 1
    ]
    return [
        point
        for point in eligible
        if not any(
            other["quality"] >= point["quality"]
            and other["total_tokens"] <= point["total_tokens"]
            and (
                other["quality"] > point["quality"] or other["total_tokens"] < point["total_tokens"]
            )
            for other in eligible
        )
    ]
