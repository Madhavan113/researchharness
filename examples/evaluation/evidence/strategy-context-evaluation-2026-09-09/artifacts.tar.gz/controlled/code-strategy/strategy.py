def apply(event):
    payload = event['payload']
    if event['kind'] == 'context':
        decision = {'keep_group_ids': [g['id'] for g in payload['groups']]}
    else:
        decision = {'order': [i['id'] for i in reversed(payload['items'])]}
    return {'decision': decision, 'state': {'calls': event['state'].get('calls', 0) + 1}}
