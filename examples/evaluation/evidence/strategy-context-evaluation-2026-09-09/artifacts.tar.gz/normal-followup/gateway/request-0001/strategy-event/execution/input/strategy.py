def apply(event):
    return {'decision': {'keep_group_ids': event['payload']['required_group_ids']},
            'state': {'calls': event['state'].get('calls', 0) + 1}}
