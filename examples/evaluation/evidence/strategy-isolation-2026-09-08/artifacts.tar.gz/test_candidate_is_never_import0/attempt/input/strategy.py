from pathlib import Path
Path('/private/tmp/rh-strategy-isolation-tests-20260908-final/test_candidate_is_never_import0/host-executed').touch()
