def apply(event):
 while True: print("x" * 65536)