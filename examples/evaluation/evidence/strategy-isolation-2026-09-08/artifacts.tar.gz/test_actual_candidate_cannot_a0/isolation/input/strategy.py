import os, pathlib, socket

def apply(event):
    result = {'host_env_absent': 'OPENAI_API_KEY' not in os.environ,
              'host_file_absent': not pathlib.Path(event['private']).exists(),
              'nonroot': os.getuid() != 0, 'docker_socket_absent': not pathlib.Path('/var/run/docker.sock').exists()}
    for name, path in [('input_readonly', '/input/strategy.py'), ('root_readonly', '/etc/strategy-test')]:
        try:
            pathlib.Path(path).write_text('changed')
            result[name] = False
        except OSError:
            result[name] = True
    try:
        socket.create_connection(('1.1.1.1', 53), timeout=0.3).close()
        result['network_denied'] = False
    except OSError:
        result['network_denied'] = True
    return result
