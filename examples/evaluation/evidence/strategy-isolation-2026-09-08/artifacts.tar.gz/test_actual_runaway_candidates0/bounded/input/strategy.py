def apply(event):
 while True: pass