# Public feed for the supplied research brief

Find an official public feed of transit service notices with stable ids and publication timestamps.

## Data requirements

- **feed** (required): Find an official public feed of transit service notices with stable ids and publication timestamps.

## Source assessment

### Authored public JSON feed

Status: **ready**. Covers: feed.

Find an official public feed of transit service notices with stable ids and publication timestamps.

Freshness: Publication timestamp present in the observed sample

History: No historical coverage claim

Access: Authored public source fixture

- [Source evidence 1](https://transit.search-fixture.example/notices.json)

Probe: `5d5e696c29e64523b6d0331c36a2b7e5`. This is a sampled compatibility check.

- Software fixture does not establish live source quality

## Coverage gaps

Every required need has a source that passed a sample probe. Semantic completeness still needs review.

## Execution

`pipeline.json`, when present, contains only sources backed by matching successful probes. Run it with `rh run pipeline.json`. Polling intervals are configuration; no background schedule is installed. The full ingestion run validates pagination and publishes each source atomically.
