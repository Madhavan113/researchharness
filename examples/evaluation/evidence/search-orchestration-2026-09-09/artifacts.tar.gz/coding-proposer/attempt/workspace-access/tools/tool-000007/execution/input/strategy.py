
import base64, os, pathlib, signal, stat, subprocess, sys, threading, time

def apply(event):
    root = pathlib.Path('/workspace')
    for rel in event['seed_files']:
        source = pathlib.Path('/seed') / rel
        destination = root / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
    command = ['/usr/local/bin/python3', '-I', '-B', '/seed/' + event['script'], *event['arguments']]
    child = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             env={'PATH': '/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8'},
                             start_new_session=True)
    streams = {'stdout': bytearray(), 'stderr': bytearray()}
    overflow = threading.Event()
    errors = []
    def collect(name, pipe):
        try:
            while True:
                chunk = os.read(pipe.fileno(), 4096)
                if not chunk:
                    break
                remaining = event['max_stream_bytes'] - len(streams[name])
                saved = chunk[:max(0, remaining)]
                streams[name].extend(saved)
                # Retains available output even if wrapper is subsequently terminated.
                os.write(2, saved)
                if len(chunk) > remaining:
                    overflow.set()
                    break
        except BaseException as exc:
            errors.append(type(exc).__name__)
    readers = [threading.Thread(target=collect, args=(n, p), daemon=True)
               for n, p in [('stdout', child.stdout), ('stderr', child.stderr)]]
    for reader in readers:
        reader.start()
    deadline = time.monotonic() + event['child_timeout_seconds']
    timed_out = False
    while child.poll() is None:
        if overflow.is_set() or errors or time.monotonic() >= deadline:
            timed_out = time.monotonic() >= deadline
            break
        time.sleep(0.01)
    # Kill the entire group, including background descendants after a normal exit.
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait(timeout=2)
    for reader in readers:
        reader.join(1)
    complete = not any(t.is_alive() for t in readers) and not errors and not overflow.is_set()
    result = {'status': 'completed' if child.returncode == 0 and complete and not timed_out else 'failed',
              'exit_code': child.returncode, 'timed_out': timed_out,
              'output_complete': complete, 'output_truncated': overflow.is_set(),
              'stdout_base64': base64.b64encode(streams['stdout']).decode(),
              'stderr_base64': base64.b64encode(streams['stderr']).decode(), 'files': {}}
    if result['status'] != 'completed':
        return result
    total = 0
    entries = 0
    try:
        for parent, dirs, names in os.walk(root, followlinks=False):
            entries += len(dirs) + len(names)
            if entries > event['max_entries']:
                raise ValueError('workspace entry limit exceeded')
            for name in dirs + names:
                path = pathlib.Path(parent) / name
                info = path.lstat()
                if stat.S_ISLNK(info.st_mode) or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)):
                    raise ValueError('workspace contains a link or special file')
                rel = path.relative_to(root).as_posix()
                if len(rel) > event['max_path_chars']:
                    raise ValueError('workspace path limit exceeded')
                if stat.S_ISDIR(info.st_mode):
                    continue
                if info.st_nlink != 1 or info.st_size > event['max_file_bytes']:
                    raise ValueError('workspace file is linked or oversized')
                raw = path.read_bytes()
                total += len(raw)
                if total > event['max_workspace_bytes'] or len(result['files']) >= event['max_files']:
                    raise ValueError('workspace size or file limit exceeded')
                result['files'][rel] = base64.b64encode(raw).decode()
    except BaseException as exc:
        result.update(status='failed', files={}, file_error=str(exc))
    return result
