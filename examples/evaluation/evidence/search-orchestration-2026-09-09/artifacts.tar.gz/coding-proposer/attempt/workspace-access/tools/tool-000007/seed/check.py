import runpy
strategy = runpy.run_path('/workspace/candidates/one/strategy.py')
result = strategy['apply']({'payload': {'required_group_ids': ['current']}})
assert result == {'decision': {'keep_group_ids': ['current']}, 'state': {}}
print('candidate checked')
