def apply(event):
    return {'decision': {'keep_group_ids': event['payload']['required_group_ids']},
            'state': {}}
