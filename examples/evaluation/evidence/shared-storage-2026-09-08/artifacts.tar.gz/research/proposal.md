# Shared storage policy

Collect the authored policy fixture

## Data requirements

- **policy** (required): Official policy

## Source assessment

### Authored policy

Status: **ready**. Covers: policy.

Test shared storage

Freshness: Fixture

History: One authored record

Access: Loopback fixture only

- [Source evidence 1](http://127.0.0.1:56554/policy.json)

Probe: `ab55a27815eb44f0a0686eee9589d647`. This is a sampled compatibility check.

- No live source or model quality claim

## Coverage gaps

Every required need has a source that passed a sample probe. Semantic completeness still needs review.

## Execution

`pipeline.json`, when present, contains only sources backed by matching successful probes. Run it with `rh run pipeline.json`. Polling intervals are configuration; no background schedule is installed. The full ingestion run validates pagination and publishes each source atomically.
