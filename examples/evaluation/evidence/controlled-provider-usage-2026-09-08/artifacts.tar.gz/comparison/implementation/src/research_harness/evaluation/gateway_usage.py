"""Independently verify usage in a sealed, host-owned model gateway archive.

Hashes establish consistency with the supplied archive and execution binding.
They are not signatures or proof that candidate code could not write the files.
"""

from __future__ import annotations

import gzip
import io
import json
import re
import zlib
from copy import deepcopy
from pathlib import Path, PurePosixPath
from typing import Any

from research_harness.execution import DiscoverySettings, GatewayBinding
from research_harness.util import digest

_ADAPTER = "controlled-responses-gateway"
_HASH = re.compile(r"^[0-9a-f]{64}$")
_MAX_FILE_BYTES = 64 * 1024 * 1024
_REQUEST_FIELDS = {
    "model",
    "input",
    "instructions",
    "tools",
    "tool_choice",
    "text",
    "stream",
    "include",
    "max_output_tokens",
    "reasoning",
    "parallel_tool_calls",
    "store",
    "metadata",
    "background",
}
_TERMINALS = {"response.completed", "response.incomplete", "response.failed"}


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError(f"Non-finite JSON number: {value}")


def _json(raw: bytes | str) -> Any:
    return json.loads(raw, object_pairs_hook=_object, parse_constant=_invalid_constant)


def _same(left: Any, right: Any) -> bool:
    # Python equality alone treats True, 1, and 1.0 as identical.
    options = {"sort_keys": True, "separators": (",", ":"), "allow_nan": False}
    return json.dumps(left, **options) == json.dumps(right, **options)


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _count(value: Any, name: str) -> int:
    _require(type(value) is int and value >= 0, f"Invalid {name} counter")
    return value


def _dict(value: Any, name: str) -> dict:
    _require(isinstance(value, dict), f"{name} must be an object")
    return value


def _local_file(root: Path, relative: str) -> Path:
    _require(isinstance(relative, str) and bool(relative), "Invalid archive file path")
    item = PurePosixPath(relative)
    _require(
        not item.is_absolute()
        and str(item) == relative
        and ".." not in item.parts
        and "\\" not in relative,
        "Archive file paths must be normalized local relative paths",
    )
    path = root
    for part in item.parts:
        path = path / part
        _require(not path.is_symlink(), "Archive cannot contain symlinks")
    _require(path.is_file(), f"Missing archive file: {relative}")
    _require(path.stat().st_size <= _MAX_FILE_BYTES, "Archive file exceeds verification limit")
    return path


def _read_archive(path: Path, result: dict) -> tuple[dict[str, bytes], dict]:
    _require(not path.is_symlink(), "Archive path cannot be a symlink")
    path = path / "archive.json" if path.is_dir() else path
    _require(path.name == "archive.json", "Expected gateway archive.json or its directory")
    root = path.parent.resolve()
    index_path = _local_file(root, "archive.json")
    index_raw = index_path.read_bytes()
    result["files"]["archive.json"] = {"path": str(index_path), "sha256": digest(index_raw)}
    index = _dict(_json(index_raw), "Archive index")
    _require(set(index) == {"schema_version", "files"}, "Unsupported archive index fields")
    _require(
        type(index["schema_version"]) is int and index["schema_version"] == 1,
        "Unsupported archive schema",
    )
    entries = _dict(index["files"], "Archive files")
    _require("archive.json" not in entries, "Archive cannot index itself")
    actual = set()
    for item in root.rglob("*"):
        _require(not item.is_symlink(), "Archive cannot contain symlinks")
        if item.is_file() and item != index_path:
            actual.add(item.relative_to(root).as_posix())
    _require(actual == set(entries), "Archive file inventory does not match the directory")
    contents = {}
    for relative, expected in entries.items():
        _require(
            isinstance(expected, str) and bool(_HASH.fullmatch(expected)),
            "Invalid archive file hash",
        )
        file = _local_file(root, relative)
        raw = file.read_bytes()
        observed = digest(raw)
        result["files"][relative] = {"path": str(file), "sha256": observed}
        _require(observed == expected, f"Archive hash mismatch: {relative}")
        contents[relative] = raw
    _require({"gateway.json", "report.json"} <= set(contents), "Missing gateway or report file")
    return contents, _dict(_json(contents["gateway.json"]), "Gateway metadata")


def _provider_response(
    raw: bytes, content_type: str, encoding: str | None
) -> tuple[dict | None, str | None, set[str], set[str]]:
    """Parse provider bytes independently; absent/partial usage stays unknown."""
    models, identities = set(), set()

    def remember(response):
        if isinstance(response, dict):
            if isinstance(response.get("model"), str):
                models.add(response["model"])
            if isinstance(response.get("id"), str) and response["id"]:
                identities.add(response["id"])

    try:
        if encoding == "gzip":
            with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
                raw = stream.read(_MAX_FILE_BYTES + 1)
            _require(len(raw) <= _MAX_FILE_BYTES, "Decoded response exceeds verification limit")
        elif encoding not in {None, "identity"}:
            return None, "unsupported_response_encoding", models, identities
        responses = []
        if "text/event-stream" in content_type.lower():
            data = []
            declared_type = None
            for line in raw.decode("utf-8").splitlines() + [""]:
                if line.startswith("event:"):
                    declared_type = line[6:].strip()
                elif line.startswith("data:"):
                    data.append(line[5:].lstrip())
                elif not line:
                    if data:
                        payload = "\n".join(data)
                        if payload != "[DONE]":
                            event = _dict(_json(payload), "SSE event")
                            remember(event.get("response"))
                            kind = event.get("type")
                            if kind in _TERMINALS:
                                _require(
                                    declared_type in {None, kind},
                                    "SSE terminal event type conflict",
                                )
                                response = _dict(event.get("response"), "Terminal response")
                                _require(
                                    response.get("status") == kind.removeprefix("response."),
                                    "SSE terminal status conflict",
                                )
                                responses.append(response)
                    data = []
                    declared_type = None
        else:
            responses = [_dict(_json(raw), "Provider response")]
            remember(responses[0])
    except (ValueError, OSError, EOFError, UnicodeError, TypeError, zlib.error) as exc:
        return None, f"unreadable_provider_response:{type(exc).__name__}", models, identities
    if len(responses) > 1:
        raise ValueError("Multiple terminal provider responses in one dispatch")
    _require(len(identities) <= 1, "Conflicting provider response ids within one dispatch")
    return (
        (responses[0] if responses else None),
        (None if responses else "missing_terminal_response"),
        models,
        identities,
    )


def _observation(response: dict | None) -> tuple[dict | None, str | None]:
    if response is None:
        return None, "missing_provider_response"
    if response.get("status") not in {"completed", "incomplete", "failed"}:
        return None, "nonterminal_response"
    if not isinstance(response.get("id"), str) or not response["id"]:
        return None, "missing_response_id"
    usage = response.get("usage")
    if not isinstance(usage, dict):
        return None, "missing_provider_usage"
    try:
        input_tokens = _count(usage.get("input_tokens"), "provider input tokens")
        output_tokens = _count(usage.get("output_tokens"), "provider output tokens")
        if "total_tokens" in usage:
            _require(
                _count(usage["total_tokens"], "provider total tokens")
                == input_tokens + output_tokens,
                "Inconsistent provider token counters",
            )
        details = usage.get("input_tokens_details")
        if details is not None:
            _dict(details, "Provider input-token details")
            if "cached_tokens" in details:
                _require(
                    _count(details["cached_tokens"], "cached input tokens") <= input_tokens,
                    "Cached tokens exceed input tokens",
                )
    except ValueError:
        return None, "invalid_provider_usage_counters"
    return {
        "response_id": response["id"],
        "model": response.get("model"),
        "status": response["status"],
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "provider_usage": usage,
    }, None


def _verify_forwarded(
    incoming: dict, forwarded: dict, record: dict, gateway: dict, settings: dict
) -> None:
    _require(not (set(incoming) - _REQUEST_FIELDS), "Unsupported forwarded request controls")
    _require(incoming.get("background", False) is False, "Background provider work is forbidden")
    if "text" in incoming:
        _require(
            isinstance(incoming["text"], dict) and not (set(incoming["text"]) - {"format"}),
            "Unsupported text controls",
        )
    items = incoming.get("input", [])
    _require(
        not (
            isinstance(items, list)
            and any(
                isinstance(item, dict) and item.get("type") == "item_reference" for item in items
            )
        ),
        "Opaque provider context reference",
    )
    tools = incoming.get("tools", [])
    _require(
        isinstance(tools, list)
        and all(isinstance(tool, dict) and tool.get("type") == "function" for tool in tools),
        "Provider-native tools cannot establish bounded gateway usage",
    )
    expected = deepcopy(incoming)
    stripped = []
    allowed = gateway.get("allowed_function_names")
    if allowed is not None:
        _require(
            isinstance(allowed, list) and all(isinstance(name, str) for name in allowed),
            "Invalid allowed function names",
        )
        expected["tools"] = [tool for tool in tools if tool.get("name") in allowed]
        stripped = [tool.get("name") for tool in tools if tool.get("name") not in allowed]
        choice = incoming.get("tool_choice")
        _require(
            not isinstance(choice, dict) or choice.get("name") in allowed, "Forbidden tool choice"
        )
    expected.update(settings)
    expected.pop("parallel_tool_calls", None)
    _require(_same(expected, forwarded), "Forwarded request does not match recorded controls")
    _require(
        _same(record.get("stripped_function_names"), stripped), "Stripped tool metadata mismatch"
    )
    changes = {
        key: {"incoming": incoming.get(key), "forwarded": forwarded.get(key)}
        for key in ("max_output_tokens", "reasoning", "parallel_tool_calls")
        if not _same(incoming.get(key), forwarded.get(key))
        or (key in incoming) != (key in forwarded)
    }
    _require(
        _same(record.get("control_changes"), changes), "Request control-change metadata mismatch"
    )


def verify_gateway_usage(
    archive_path: Path,
    expected_binding: GatewayBinding,
    *,
    expected_model: str,
    expected_model_settings: dict | None = None,
    expected_budgets: dict | None = None,
) -> dict[str, Any]:
    """Verify an execution's raw provider usage without requiring a proposal.

    A complete result measures provider token accounting, including terminal
    failed/incomplete responses. It does not establish task success or cost.
    Duplicate provider ids invalidate the evidence rather than inflate totals.
    """
    result: dict[str, Any] = {
        "status": "invalid",
        "total_tokens": None,
        "completed_token_lower_bound": None,
        "input_tokens": None,
        "output_tokens": None,
        "cached_input_tokens": None,
        "cached_input_token_lower_bound": None,
        "returned_models": [],
        "dispatched_requests": None,
        "reserved_attempts": None,
        "response_count": 0,
        "files": {},
        "errors": [],
        "unknown_requests": [],
        "responses": [],
        "cost_usd": None,
        "limitations": [
            "Host archive consistency is not a signature or access-isolation proof.",
            "Token accounting does not establish task success or provider billing.",
        ],
    }
    try:
        binding = GatewayBinding.model_validate(expected_binding)
        _require(
            isinstance(expected_model, str) and bool(expected_model.strip()),
            "Expected model is required",
        )
        contents, gateway = _read_archive(Path(archive_path), result)
        _require(
            gateway.get("schema_version") == 1
            and type(gateway.get("schema_version")) is int
            and gateway.get("adapter") == _ADAPTER,
            "Unsupported gateway metadata",
        )
        observed_binding = GatewayBinding.model_validate(gateway.get("binding"))
        _require(observed_binding == binding, "Gateway execution binding mismatch")
        result["binding"] = observed_binding.model_dump(mode="json")
        _require(gateway.get("model") == expected_model, "Gateway model mismatch")
        settings = DiscoverySettings.model_validate(gateway.get("discovery_settings"))
        model_settings = settings.model_settings()
        if expected_model_settings is not None:
            _require(
                _same(expected_model_settings, model_settings), "Gateway model settings mismatch"
            )
        if expected_budgets is not None:
            _require(
                _same(expected_budgets, settings.budgets()), "Gateway execution budgets mismatch"
            )
        _require(
            gateway.get("auxiliary_endpoint_policy") == "reject_without_forwarding"
            and gateway.get("parallel_tool_calls") == "omitted",
            "Unsupported gateway control policy",
        )
        report = _dict(_json(contents["report.json"]), "Gateway report")
        _require(
            type(report.get("schema_version")) is int
            and report["schema_version"] == 1
            and report.get("adapter") == _ADAPTER,
            "Unsupported gateway report",
        )
        _require(report.get("closed") is True, "Gateway report is not sealed and closed")
        _require(report.get("model") == expected_model, "Gateway report model mismatch")
        _require(
            _same(report.get("max_rounds"), settings.max_rounds)
            and _same(report.get("deadline_seconds"), settings.deadline_seconds),
            "Report limits mismatch",
        )
        _require(report.get("auxiliary_usage_unknown") is False, "Unknown auxiliary usage policy")
        records = report.get("requests")
        _require(isinstance(records, list), "Gateway requests must be a list")
        expected_files = {"gateway.json", "report.json"}
        reserved, dispatched, observations, response_ids, models, unknown = (
            [],
            [],
            [],
            set(),
            set(),
            [],
        )
        denials = []
        interrupted = False
        for index, value in enumerate(records, 1):
            record = _dict(value, "Request record")
            identity = f"request-{index:04d}"
            _require(record.get("id") == identity, "Request identity/order mismatch")
            prefix = identity + "/"
            expected_files.update({prefix + "record.json", prefix + "incoming.json"})
            _require(
                _same(_json(contents[prefix + "record.json"]), record),
                "Report request differs from record file",
            )
            _require(
                record.get("incoming_sha256") == digest(contents[prefix + "incoming.json"]),
                "Incoming request hash mismatch",
            )
            outcome = record.get("outcome")
            _require(
                outcome in {"completed", "interrupted", "denied"}, "Nonterminal archived request"
            )
            _require(isinstance(record.get("finished_at"), str), "Request has no finish time")
            _require(
                type(record.get("forwarded")) is bool
                and type(record.get("dispatch_started")) is bool
                and record["forwarded"] == record["dispatch_started"],
                "Dispatch flags mismatch",
            )
            reservation = record.get("reserved_attempt_number")
            if reservation is not None:
                _require(
                    _count(reservation, "reserved attempt") > 0, "Invalid reserved attempt number"
                )
                reserved.append(reservation)
                expected_files.add(prefix + "forwarded.json")
                raw_forwarded = contents[prefix + "forwarded.json"]
                _require(
                    record.get("forwarded_sha256") == digest(raw_forwarded),
                    "Forwarded request hash mismatch",
                )
                incoming = _dict(_json(contents[prefix + "incoming.json"]), "Incoming request")
                forwarded = _dict(_json(raw_forwarded), "Forwarded request")
                _require(
                    record.get("path") == "/v1/responses"
                    and incoming.get("model") == expected_model
                    and forwarded.get("model") == expected_model,
                    "Forwarded model/path mismatch",
                )
                _verify_forwarded(incoming, forwarded, record, gateway, model_settings)
            else:
                _require(
                    "forwarded_sha256" not in record
                    and not record["dispatch_started"]
                    and outcome == "denied",
                    "Unreserved request has forwarding evidence",
                )
            if record["dispatch_started"]:
                number = _count(record.get("upstream_request_number"), "dispatched request")
                _require(number > 0, "Invalid dispatch number")
                dispatched.append(number)
            else:
                _require(
                    "upstream_request_number" not in record and record.get("usage") is None,
                    "Undispatched request reports provider activity",
                )
            if outcome == "denied":
                _require(
                    reservation is None and isinstance(record.get("reason"), str),
                    "Invalid denied request",
                )
                denials.append({"id": identity, "reason": record["reason"]})
            interrupted |= outcome == "interrupted"
            body = None
            if "response_sha256" in record:
                expected_files.add(prefix + "response.body")
                body = contents[prefix + "response.body"]
                _require(
                    record["response_sha256"] == digest(body), "Response capture hash mismatch"
                )
            _require(
                outcome == "denied" or body is not None,
                "Sealed accepted request lacks its terminal capture",
            )
            _require(
                outcome != "completed" or (record["dispatch_started"] and body is not None),
                "Completion lacks dispatched response capture",
            )
            if not record["dispatch_started"]:
                _require(not body, "Undispatched request contains response bytes")
                continue
            response, issue = None, "missing_response_headers"
            returned_models, provider_ids = set(), set()
            if "response_content_type" in record or "response_content_encoding" in record:
                content_type, encoding = (
                    record.get("response_content_type"),
                    record.get("response_content_encoding"),
                )
                _require(
                    "response_content_encoding" in record
                    and isinstance(content_type, str)
                    and (encoding is None or isinstance(encoding, str)),
                    "Invalid response format metadata",
                )
                _require(body is not None, "Response metadata lacks capture")
                response, issue, returned_models, provider_ids = _provider_response(
                    body, content_type, encoding
                )
            models.update(returned_models)
            result["returned_models"] = sorted(models)
            _require(not (returned_models - {expected_model}), "Returned provider model mismatch")
            _require(
                len(provider_ids) <= 1, "Conflicting provider response ids within one dispatch"
            )
            _require(not (provider_ids & response_ids), "Duplicate provider response id")
            response_ids.update(provider_ids)
            observation, usage_issue = _observation(response)
            if outcome != "completed":
                _require(record.get("usage") is None, "Interrupted dispatch claims terminal usage")
                unknown.append({"id": identity, "reason": "interrupted_dispatch"})
            else:
                _require(
                    _same(record.get("usage"), observation),
                    "Recorded usage differs from raw provider response",
                )
                if observation is None:
                    unknown.append({"id": identity, "reason": issue or usage_issue})
                else:
                    _require(
                        observation["model"] == expected_model,
                        "Usage has no expected provider model",
                    )
                    observations.append(observation)
        _require(
            set(contents) == expected_files, "Archive contains unbound or missing request files"
        )
        _require(
            sorted(reserved) == list(range(1, len(reserved) + 1))
            and len(reserved) <= settings.max_rounds,
            "Reserved attempt sequence/limit mismatch",
        )
        _require(
            sorted(dispatched) == list(range(1, len(dispatched) + 1)), "Dispatch sequence mismatch"
        )
        _require(
            _count(report.get("reserved_attempts"), "report reservations") == len(reserved)
            and _count(report.get("upstream_requests"), "report dispatches") == len(dispatched),
            "Report request counts mismatch",
        )
        _require(
            _same(report.get("denials"), denials) and report.get("interrupted") is interrupted,
            "Report terminal-state summary mismatch",
        )
        input_tokens = sum(item["input_tokens"] for item in observations)
        output_tokens = sum(item["output_tokens"] for item in observations)
        total = input_tokens + output_tokens
        totals = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total,
        }
        _require(
            _same(report.get("totals"), totals), "Report totals differ from raw provider usage"
        )
        complete = not unknown
        _require(
            report.get("complete") is complete,
            "Report completeness differs from dispatched evidence",
        )
        cached = [
            (item["provider_usage"].get("input_tokens_details") or {}).get("cached_tokens")
            for item in observations
        ]
        cached_lower = sum(value for value in cached if value is not None)
        result.update(
            status="verified_complete" if complete else "verified_lower_bound",
            total_tokens=total if complete else None,
            completed_token_lower_bound=total,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_input_tokens=cached_lower
            if complete and all(value is not None for value in cached)
            else None,
            cached_input_token_lower_bound=cached_lower,
            returned_models=sorted(models),
            dispatched_requests=len(dispatched),
            reserved_attempts=len(reserved),
            response_count=len(observations),
            interrupted=interrupted,
            auxiliary_usage_unknown=False,
            unknown_requests=unknown,
            responses=observations,
        )
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
        result["errors"].append(f"{type(exc).__name__}: {exc}")
    return result
